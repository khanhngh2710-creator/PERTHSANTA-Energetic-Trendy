# PerthSanta Energetic & Trendy

Mobile-first fan engagement hub for PerthSanta. Version 1 is a static React + Vite app: no login, database, or external APIs. Content lives in `src/data` and images live in `public/images`.

## Scripts

```bash
npm install
npm run dev
npm run build
npm run preview
```

## Edit content

- `src/data/translations.js` — English and Vietnamese copy
- `src/data/schedule.js` — events
- `src/data/missions.js` — daily missions
- `src/data/youtube.js` — streaming targets and watch links
- `src/data/instagram.js` — Instagram tasks
- `src/data/episodes.js` — episode list
- `public/images/` — replace `.webp` files, keep the same filenames

Completed missions, Instagram tasks, and to-dos are stored in `localStorage`.

## GitHub

```bash
git init
git add .
git commit -m "Initial PerthSanta engagement hub"
git branch -M main
git remote add origin https://github.com/YOUR_USER/perthsanta-energetic-trendy.git
git push -u origin main
```

## Vercel

1. Import the GitHub repository.
2. Framework preset: Vite.
3. Build command: `npm run build`
4. Output directory: `dist`
5. No environment variables are required.
