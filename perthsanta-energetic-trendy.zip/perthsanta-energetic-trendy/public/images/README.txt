Replace the .webp files in this folder to update visuals.

Expected filenames:
- logo.webp
- hero.webp
- perth.webp
- santa.webp
- pair.webp
- heartbound.webp
- yt-heartbound.webp
- yt-trailer.webp

Keep the same names so the app does not need code changes.
