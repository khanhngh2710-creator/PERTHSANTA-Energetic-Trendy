import { useMemo, useState } from "react";
import { Navigate, Route, Routes, useLocation } from "react-router-dom";
import Header from "./components/Header";
import BottomNav from "./components/BottomNav";
import TodoDrawer from "./components/TodoDrawer";
import Home from "./pages/Home";
import Trends from "./pages/Trends";
import Missions from "./pages/Missions";
import YouTubePage from "./pages/YouTube";
import Instagram from "./pages/Instagram";
import Intro from "./pages/Intro";
import Schedule from "./pages/Schedule";
import Todo from "./pages/Todo";
import TrendingGuide from "./pages/TrendingGuide";
import { todos } from "./data/todos";
import { loadIds, toggleId } from "./utils/storage";

export default function App() {
  const location = useLocation();
  const [todoOpen, setTodoOpen] = useState(false);
  const [doneIds, setDoneIds] = useState(() => loadIds("todos"));
  const todoCount = useMemo(
    () => todos.filter((item) => !doneIds.has(item.id)).length,
    [doneIds]
  );

  return (
    <div className="app-shell">
      <Header onOpenTodo={() => setTodoOpen(true)} todoCount={todoCount} />
      <main className="main" key={location.pathname}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/trends" element={<Trends />} />
          <Route path="/missions" element={<Missions />} />
          <Route path="/youtube" element={<YouTubePage />} />
          <Route path="/instagram" element={<Instagram />} />
          <Route path="/intro" element={<Intro />} />
          <Route path="/schedule" element={<Schedule />} />
          <Route path="/todo" element={<Todo doneIds={doneIds} setDoneIds={setDoneIds} />} />
          <Route path="/trending-guide" element={<TrendingGuide />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
      <BottomNav />
      <TodoDrawer
        open={todoOpen}
        onClose={() => setTodoOpen(false)}
        doneIds={doneIds}
        onToggle={(id) => setDoneIds(toggleId("todos", id))}
      />
    </div>
  );
}
