import { NavLink } from "react-router-dom";
import { useLang } from "../context/LanguageContext";

const items = [
  { to: "/", key: "home", icon: "home" },
  { to: "/trends", key: "trends", icon: "trend" },
  { to: "/missions", key: "missions", icon: "target" },
  { to: "/youtube", key: "youtube", icon: "yt" },
  { to: "/instagram", key: "instagram", icon: "ig" }
];

function Icon({ name }) {
  if (name === "home") {
    return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M4 10.5 12 4l8 6.5V20a1 1 0 0 1-1 1h-5v-6H10v6H5a1 1 0 0 1-1-1v-9.5Z" /></svg>;
  }
  if (name === "trend") {
    return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M4 16l5-5 4 4 7-8" /><path d="M14 7h6v6" /></svg>;
  }
  if (name === "target") {
    return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><circle cx="12" cy="12" r="8" /><circle cx="12" cy="12" r="4" /><circle cx="12" cy="12" r="1" fill="currentColor" /></svg>;
  }
  if (name === "yt") {
    return <svg viewBox="0 0 24 24" fill="currentColor"><path d="M22 12.2s0-3.2-.4-4.6c-.2-.9-.9-1.6-1.8-1.8C18.2 5.4 12 5.4 12 5.4s-6.2 0-7.8.4c-.9.2-1.6.9-1.8 1.8C2 9 2 12.2 2 12.2s0 3.2.4 4.6c.2.9.9 1.6 1.8 1.8 1.6.4 7.8.4 7.8.4s6.2 0 7.8-.4c.9-.2 1.6-.9 1.8-1.8.4-1.4.4-4.6.4-4.6ZM10 15.5v-6.6l5.2 3.3-5.2 3.3Z" /></svg>;
  }
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><rect x="4" y="4" width="16" height="16" rx="5" /><circle cx="12" cy="12" r="3.5" /><circle cx="17.2" cy="6.8" r="0.8" fill="currentColor" /></svg>;
}

export default function BottomNav() {
  const { t } = useLang();
  return (
    <nav className="bottom-nav" aria-label="Primary">
      {items.map((item) => (
        <NavLink key={item.to} to={item.to} end={item.to === "/"} className={({ isActive }) => `nav-item${isActive ? " active" : ""}`}>
          <Icon name={item.icon} />
          <span>{t(item.key)}</span>
        </NavLink>
      ))}
    </nav>
  );
}
