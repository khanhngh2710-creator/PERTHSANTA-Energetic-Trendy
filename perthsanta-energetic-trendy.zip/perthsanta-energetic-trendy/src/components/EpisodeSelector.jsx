export default function EpisodeSelector({ episodes, selectedId, onSelect }) {
  return (
    <div className="episode-grid" role="listbox" aria-label="Episodes">
      {episodes.map((episode) => (
        <button
          key={episode.id}
          type="button"
          className={`ep-btn${selectedId === episode.id ? " selected" : ""}`}
          aria-pressed={selectedId === episode.id}
          onClick={() => onSelect(episode.id)}
        >
          {episode.code}
        </button>
      ))}
    </div>
  );
}
