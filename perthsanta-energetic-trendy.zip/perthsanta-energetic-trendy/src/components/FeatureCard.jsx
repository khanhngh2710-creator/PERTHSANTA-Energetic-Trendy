import { Link } from "react-router-dom";

function Icon({ name }) {
  if (name === "heart") {
    return <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor"><path d="M12 20s-7-4.4-7-9a4 4 0 0 1 7-2 4 4 0 0 1 7 2c0 4.6-7 9-7 9Z" /></svg>;
  }
  if (name === "target") {
    return <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><circle cx="12" cy="12" r="8" /><circle cx="12" cy="12" r="4" /><circle cx="12" cy="12" r="1" fill="currentColor" /></svg>;
  }
  if (name === "yt") {
    return <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor"><path d="M22 12.2s0-3.2-.4-4.6c-.2-.9-.9-1.6-1.8-1.8C18.2 5.4 12 5.4 12 5.4s-6.2 0-7.8.4c-.9.2-1.6.9-1.8 1.8C2 9 2 12.2 2 12.2s0 3.2.4 4.6c.2.9.9 1.6 1.8 1.8 1.6.4 7.8.4 7.8.4s6.2 0 7.8-.4c.9-.2 1.6-.9 1.8-1.8.4-1.4.4-4.6.4-4.6ZM10 15.5v-6.6l5.2 3.3-5.2 3.3Z" /></svg>;
  }
  return <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><rect x="4" y="4" width="16" height="16" rx="5" /><circle cx="12" cy="12" r="3.5" /><circle cx="17.2" cy="6.8" r="0.8" fill="currentColor" /></svg>;
}

export default function FeatureCard({ to, icon, title, subtitle }) {
  return (
    <Link to={to} className="glass feature">
      <span className="icon-bubble" aria-hidden="true"><Icon name={icon} /></span>
      <span className="grow">
        <h2 style={{ fontSize: 16 }}>{title}</h2>
        <p>{subtitle}</p>
      </span>
      <span className="arrow" aria-hidden="true">›</span>
    </Link>
  );
}
