export default function GlassCard({ children, className = "" }) {
  return <article className={`glass ${className}`.trim()}>{children}</article>;
}
