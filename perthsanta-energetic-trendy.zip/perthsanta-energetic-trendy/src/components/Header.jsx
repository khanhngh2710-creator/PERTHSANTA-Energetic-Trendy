import { Link } from "react-router-dom";
import { useLang } from "../context/LanguageContext";

export default function Header({ onOpenTodo, todoCount }) {
  const { t, lang, toggleLang } = useLang();
  return (
    <header className="topbar">
      <Link to="/" className="brand" aria-label="PerthSanta home">
        <img src="/images/logo.webp" alt="" />
        <span>{t("brand")}</span>
      </Link>
      <div className="top-actions">
        <Link to="/intro" className="chip">{t("intro")}</Link>
        <button type="button" className="chip" onClick={onOpenTodo} aria-label={t("todo")}>
          {t("todo")}
          {todoCount > 0 ? <span className="badge">{todoCount}</span> : null}
        </button>
        <button type="button" className="chip lang" onClick={toggleLang} aria-label={t("langLabel")}>
          {lang === "vi" ? "VI" : "EN"}
        </button>
      </div>
    </header>
  );
}
