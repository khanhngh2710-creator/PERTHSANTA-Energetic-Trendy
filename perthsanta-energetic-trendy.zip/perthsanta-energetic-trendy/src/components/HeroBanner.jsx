import { useLang } from "../context/LanguageContext";

export default function HeroBanner() {
  const { t } = useLang();
  return (
    <section className="hero" aria-label={t("heroTitle")}>
      <img src="/images/hero.webp" alt="" />
      <div className="hero-overlay">
        <p className="eyebrow">{t("heroSub")}</p>
        <h1>{t("heroTitle")}</h1>
      </div>
    </section>
  );
}
