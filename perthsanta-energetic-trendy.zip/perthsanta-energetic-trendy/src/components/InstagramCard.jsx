import { useLang } from "../context/LanguageContext";

export default function InstagramCard({ task, done, onToggle }) {
  const { t } = useLang();
  return (
    <article className="glass ig-card">
      <p className="pill" style={{ display: "inline-block" }}>Instagram</p>
      <h2 style={{ fontSize: 16, margin: "10px 0 0" }}>{t(task.titleKey)}</h2>
      <p className="muted">{t(task.descKey)}</p>
      <div className="actions">
        <a href={task.href} target="_blank" rel="noreferrer">{t("openIgBtn")}</a>
        <button type="button" className={`btn${done ? " done" : ""}`} onClick={onToggle}>
          {done ? `✓ ${t("done")}` : t("complete")}
        </button>
      </div>
    </article>
  );
}
