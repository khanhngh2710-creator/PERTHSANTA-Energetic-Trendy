import { useLang } from "../context/LanguageContext";

export default function LanguageToggle() {
  const { lang, toggleLang, t } = useLang();
  return (
    <button type="button" className="chip lang" onClick={toggleLang} aria-label={t("langLabel")}>
      {lang === "vi" ? "VI" : "EN"}
    </button>
  );
}
