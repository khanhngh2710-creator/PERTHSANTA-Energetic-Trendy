import { useLang } from "../context/LanguageContext";

export default function MissionCard({ mission, done, onToggle }) {
  const { t } = useLang();
  return (
    <article className="glass mission">
      <div className="row-between">
        <h2 style={{ fontSize: 16, margin: 0 }}>{t(mission.titleKey)}</h2>
        {done ? <span aria-hidden="true">✓</span> : null}
      </div>
      <p className="muted" style={{ margin: 0 }}>{t(mission.descKey)}</p>
      <div className="tags">
        <span className="pill">{t("platform")}: {mission.platform}</span>
        <span className="pill">{t("reward")}: {mission.reward} {t("points")}</span>
        <span className="pill">{t("status")}: {done ? t("done") : t("open")}</span>
      </div>
      <button type="button" className={`btn${done ? " done" : ""}`} onClick={onToggle}>
        {done ? `✓ ${t("done")}` : t("complete")}
      </button>
    </article>
  );
}
