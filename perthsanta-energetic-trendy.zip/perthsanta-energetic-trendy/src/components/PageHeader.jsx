import { Link } from "react-router-dom";
import { useLang } from "../context/LanguageContext";

export default function PageHeader({ title, subtitle, back = true }) {
  const { t } = useLang();
  return (
    <header className="page-header">
      {back ? <Link className="back-link" to="/">← {t("back")}</Link> : null}
      <h1>{title}</h1>
      {subtitle ? <p>{subtitle}</p> : null}
    </header>
  );
}
