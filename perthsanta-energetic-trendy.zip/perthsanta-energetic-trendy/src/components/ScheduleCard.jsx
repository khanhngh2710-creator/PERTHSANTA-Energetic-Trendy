import { useLang } from "../context/LanguageContext";

export default function ScheduleCard({ item }) {
  const { t } = useLang();
  return (
    <article className="glass schedule-card">
      <div className="row-between">
        <strong>{item.date}</strong>
        <span className="pill">{item.category}</span>
      </div>
      <h2 style={{ fontSize: 18, margin: "8px 0 0" }}>{item.title}</h2>
      <p className="muted">{item.time}</p>
      <p className="muted" style={{ marginTop: 0 }}>{t("location")}: {item.location}</p>
      <p className="muted" style={{ marginTop: 0 }}>{t("people")}: {item.people.join(", ")}</p>
    </article>
  );
}
