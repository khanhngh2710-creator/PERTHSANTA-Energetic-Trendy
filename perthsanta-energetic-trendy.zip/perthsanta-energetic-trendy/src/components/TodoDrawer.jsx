import { Link } from "react-router-dom";
import { useLang } from "../context/LanguageContext";
import { todos } from "../data/todos";

export default function TodoDrawer({ open, onClose, doneIds, onToggle }) {
  const { t } = useLang();
  if (!open) return null;
  return (
    <div className="drawer-backdrop" onClick={onClose} role="presentation">
      <aside className="drawer" role="dialog" aria-modal="true" aria-label={t("todoTitle")} onClick={(event) => event.stopPropagation()}>
        <div className="row-between">
          <h2 style={{ margin: 0 }}>{t("todoTitle")}</h2>
          <button type="button" className="btn ghost" onClick={onClose}>{t("close")}</button>
        </div>
        <p className="muted">{t("todoSub")}</p>
        <div className="stack">
          {todos.map((item) => {
            const done = doneIds.has(item.id);
            return (
              <article key={item.id} className="glass" style={{ padding: 14 }}>
                <h3 style={{ margin: "0 0 4px" }}>{t(item.titleKey)}</h3>
                <p className="muted" style={{ marginTop: 0 }}>{t(item.descKey)}</p>
                <div className="actions">
                  <Link to={item.href} onClick={onClose}>{t("open")}</Link>
                  <button type="button" className={`btn${done ? " done" : ""}`} onClick={() => onToggle(item.id)}>
                    {done ? `✓ ${t("done")}` : t("complete")}
                  </button>
                </div>
              </article>
            );
          })}
        </div>
      </aside>
    </div>
  );
}
