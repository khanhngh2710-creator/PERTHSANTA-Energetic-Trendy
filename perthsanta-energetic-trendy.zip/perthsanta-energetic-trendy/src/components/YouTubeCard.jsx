import { useLang } from "../context/LanguageContext";
import ProgressBar from "./ProgressBar";

function format(n) {
  return new Intl.NumberFormat("en-US").format(n);
}

export default function YouTubeCard({ video }) {
  const { t } = useLang();
  const remaining = Math.max(video.targetViews - video.currentViews, 0);
  return (
    <article className="glass video-card">
      <img className="thumb" src={video.thumbnail} alt="" />
      <h2 style={{ fontSize: 16, margin: "12px 0 0" }}>{video.title}</h2>
      <div className="stats">
        <div className="stat">{t("views")}<strong>{format(video.currentViews)}</strong></div>
        <div className="stat">{t("target")}<strong>{format(video.targetViews)}</strong></div>
        <div className="stat">{t("remaining")}<strong>{format(remaining)}</strong></div>
      </div>
      <ProgressBar value={video.currentViews} max={video.targetViews} />
      <div style={{ marginTop: 12 }}>
        <a className="btn" href={video.url} target="_blank" rel="noreferrer" style={{ display: "inline-block", textDecoration: "none" }}>
          {t("watch")}
        </a>
      </div>
    </article>
  );
}
