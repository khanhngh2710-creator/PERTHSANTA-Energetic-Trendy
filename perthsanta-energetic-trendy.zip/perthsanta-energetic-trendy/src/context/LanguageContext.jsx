import { createContext, useContext, useEffect, useMemo, useState } from "react";
import { translations } from "../data/translations";

const LanguageContext = createContext(null);

export function LanguageProvider({ children }) {
  const [lang, setLang] = useState(() => localStorage.getItem("perthsanta.lang") || "en");

  useEffect(() => {
    localStorage.setItem("perthsanta.lang", lang);
    document.documentElement.lang = lang === "vi" ? "vi" : "en";
  }, [lang]);

  const value = useMemo(() => {
    const dict = translations[lang] || translations.en;
    return {
      lang,
      setLang,
      toggleLang: () => setLang((current) => (current === "en" ? "vi" : "en")),
      t: (key) => dict[key] || translations.en[key] || key
    };
  }, [lang]);

  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
}

export function useLang() {
  const ctx = useContext(LanguageContext);
  if (!ctx) throw new Error("useLang must be used within LanguageProvider");
  return ctx;
}
