export const episodes = [
  { id: 1, code: "EP 1", title: "First Spark", note: "Opening chapter of Heartbound." },
  { id: 2, code: "EP 2", title: "Crossed Paths", note: "The pair share a quieter scene." },
  { id: 3, code: "EP 3", title: "Late Signal", note: "Fans highlight the night sequence." },
  { id: 4, code: "EP 4", title: "Unsaid", note: "Dialogue-heavy episode." },
  { id: 5, code: "EP 5", title: "Halfway", note: "Mid-series turning point." },
  { id: 6, code: "EP 6", title: "Heartbound", note: "Focus episode for today's trend push." },
  { id: 7, code: "EP 7", title: "Afterglow", note: "Soft follow-up chapter." },
  { id: 8, code: "EP 8", title: "Distance", note: "Tension episode." },
  { id: 9, code: "EP 9", title: "Return", note: "Reunion beat." },
  { id: 10, code: "EP 10", title: "Together", note: "Finale chapter." }
];

export const generators = [
  { id: "tags", nameKey: "genTags", available: false },
  { id: "captions", nameKey: "genCaptions", available: false },
  { id: "clips", nameKey: "genClips", available: false }
];
