export const instagramTasks = [
  {
    id: "ig-like",
    titleKey: "igLikeTitle",
    descKey: "igLikeDesc",
    href: "https://www.instagram.com/explore/tags/perthsanta/"
  },
  {
    id: "ig-comment",
    titleKey: "igCommentTitle",
    descKey: "igCommentDesc",
    href: "https://www.instagram.com/explore/tags/perthsanta/"
  },
  {
    id: "ig-save",
    titleKey: "igSaveTitle",
    descKey: "igSaveDesc",
    href: "https://www.instagram.com/explore/tags/perthsanta/"
  },
  {
    id: "ig-share",
    titleKey: "igShareTitle",
    descKey: "igShareDesc",
    href: "https://www.instagram.com/explore/tags/perthsanta/"
  },
  {
    id: "ig-follow",
    titleKey: "igFollowTitle",
    descKey: "igFollowDesc",
    href: "https://www.instagram.com/gmmtv/"
  }
];
