export const missions = [
  {
    id: "like-post",
    titleKey: "mLikeTitle",
    descKey: "mLikeDesc",
    platform: "X",
    reward: 10
  },
  {
    id: "comment-post",
    titleKey: "mCommentTitle",
    descKey: "mCommentDesc",
    platform: "X",
    reward: 15
  },
  {
    id: "repost-x",
    titleKey: "mRepostTitle",
    descKey: "mRepostDesc",
    platform: "X",
    reward: 15
  },
  {
    id: "watch-yt",
    titleKey: "mWatchTitle",
    descKey: "mWatchDesc",
    platform: "YouTube",
    reward: 20
  },
  {
    id: "share-official",
    titleKey: "mShareTitle",
    descKey: "mShareDesc",
    platform: "Multi",
    reward: 10
  },
  {
    id: "gmmtv",
    titleKey: "mGmmtvTitle",
    descKey: "mGmmtvDesc",
    platform: "Instagram",
    reward: 15
  },
  {
    id: "save-ig",
    titleKey: "mSaveTitle",
    descKey: "mSaveDesc",
    platform: "Instagram",
    reward: 10
  },
  {
    id: "trend-tag",
    titleKey: "mTrendTitle",
    descKey: "mTrendDesc",
    platform: "X",
    reward: 20
  }
];
