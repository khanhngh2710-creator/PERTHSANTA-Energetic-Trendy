export const schedule = [
  {
    id: "evt-22",
    date: "22 Oct",
    time: "TBA",
    title: "INFINITY CLINIC",
    location: "CENTRAL WESTGATE",
    people: ["PERTH"],
    category: "EVENT"
  },
  {
    id: "evt-23",
    date: "23 Oct",
    time: "TBA",
    title: "SEOUL SOCIETY CLINIC",
    location: "BANGKOK",
    people: ["SANTA"],
    category: "EVENT"
  },
  {
    id: "evt-25",
    date: "25 Oct",
    time: "18:00",
    title: "HEARTBOUND FAN LIVE",
    location: "ONLINE",
    people: ["PERTH", "SANTA"],
    category: "LIVE"
  },
  {
    id: "evt-28",
    date: "28 Oct",
    time: "19:30",
    title: "GMMTV LINEUP NIGHT",
    location: "UNION HALL",
    people: ["PERTHSANTA"],
    category: "SHOW"
  }
];

export const trendEvent = {
  id: "trend-today",
  date: "05 Oct",
  time: "All day",
  title: "HEARTBOUND EP PUSH",
  location: "X / TikTok / Instagram",
  people: ["PERTHSANTA"],
  category: "TREND"
};
