export const todos = [
  { id: "todo-missions", titleKey: "todoMissions", descKey: "todoMissionsDesc", href: "/missions" },
  { id: "todo-streaming", titleKey: "todoStreaming", descKey: "todoStreamingDesc", href: "/youtube" },
  { id: "todo-trending", titleKey: "todoTrending", descKey: "todoTrendingDesc", href: "/trends" },
  { id: "todo-instagram", titleKey: "todoInstagram", descKey: "todoInstagramDesc", href: "/instagram" },
  { id: "todo-other", titleKey: "todoOther", descKey: "todoOtherDesc", href: "/trending-guide" }
];
