export const youtubeVideos = [
  {
    id: "heartbound-pilot",
    title: "Heartbound ดูทุกหัวใจ | GMMTV 2026",
    thumbnail: "/images/yt-heartbound.webp",
    currentViews: 1284500,
    targetViews: 2000000,
    url: "https://www.youtube.com/results?search_query=Heartbound+GMMTV+2026"
  },
  {
    id: "love-you-teacher",
    title: "[Official Trailer] ใครทำร้ายเธอ Love you teacher",
    thumbnail: "/images/yt-trailer.webp",
    currentViews: 860200,
    targetViews: 1500000,
    url: "https://www.youtube.com/results?search_query=Love+you+teacher+GMMTV+trailer"
  }
];
