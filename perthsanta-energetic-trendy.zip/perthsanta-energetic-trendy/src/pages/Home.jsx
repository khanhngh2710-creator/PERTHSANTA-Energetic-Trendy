import { useLang } from "../context/LanguageContext";
import HeroBanner from "../components/HeroBanner";
import FeatureCard from "../components/FeatureCard";

export default function Home() {
  const { t } = useLang();
  return (
    <>
      <HeroBanner />
      <div className="stack feature-grid">
        <FeatureCard to="/trends" icon="heart" title={t("cardTrends")} subtitle={t("cardTrendsSub")} />
        <FeatureCard to="/missions" icon="target" title={t("cardMissions")} subtitle={t("cardMissionsSub")} />
        <FeatureCard to="/youtube" icon="yt" title={t("cardYt")} subtitle={t("cardYtSub")} />
        <FeatureCard to="/instagram" icon="ig" title={t("cardIg")} subtitle={t("cardIgSub")} />
      </div>
      <p className="footer-note">{t("copyright")}</p>
    </>
  );
}
