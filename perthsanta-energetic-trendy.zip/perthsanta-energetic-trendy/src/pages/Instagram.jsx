import { useState } from "react";
import { useLang } from "../context/LanguageContext";
import PageHeader from "../components/PageHeader";
import InstagramCard from "../components/InstagramCard";
import { instagramTasks } from "../data/instagram";
import { loadIds, toggleId } from "../utils/storage";

export default function Instagram() {
  const { t } = useLang();
  const [done, setDone] = useState(() => loadIds("instagram"));

  return (
    <>
      <PageHeader title={t("igPageTitle")} subtitle={t("igSub")} />
      <p className="eyebrow">{t("igHeading")}</p>
      <div className="stack">
        {instagramTasks.map((task) => (
          <InstagramCard
            key={task.id}
            task={task}
            done={done.has(task.id)}
            onToggle={() => setDone(toggleId("instagram", task.id))}
          />
        ))}
      </div>
    </>
  );
}
