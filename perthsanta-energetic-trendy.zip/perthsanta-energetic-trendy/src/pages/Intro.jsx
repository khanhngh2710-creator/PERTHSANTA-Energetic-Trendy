import { Link } from "react-router-dom";
import { useLang } from "../context/LanguageContext";
import PageHeader from "../components/PageHeader";

const profiles = [
  { key: "profilePerth", bio: "perthBio", image: "/images/perth.webp" },
  { key: "profileSanta", bio: "santaBio", image: "/images/santa.webp" },
  { key: "profilePair", bio: "pairBio", image: "/images/pair.webp" }
];

export default function Intro() {
  const { t } = useLang();
  return (
    <>
      <PageHeader title={t("introTitle")} subtitle={t("introSub")} />
      <p className="muted">{t("profileNote")}</p>
      <div className="stack feature-grid">
        {profiles.map((profile) => (
          <article key={profile.key} className="glass profile-card">
            <img src={profile.image} alt={t(profile.key)} />
            <h2>{t(profile.key)}</h2>
            <p className="muted">{t(profile.bio)}</p>
          </article>
        ))}
      </div>
      <div className="actions" style={{ marginTop: 16 }}>
        <Link to="/schedule">{t("viewSchedule")}</Link>
        <Link to="/trending-guide">{t("openGuide")}</Link>
      </div>
    </>
  );
}
