import { useEffect, useState } from "react";
import { useLang } from "../context/LanguageContext";
import PageHeader from "../components/PageHeader";
import MissionCard from "../components/MissionCard";
import ProgressBar from "../components/ProgressBar";
import { missions } from "../data/missions";
import { loadIds, toggleId } from "../utils/storage";

export default function Missions() {
  const { t } = useLang();
  const [done, setDone] = useState(() => loadIds("missions"));

  useEffect(() => {
    const sync = () => setDone(loadIds("missions"));
    window.addEventListener("focus", sync);
    return () => window.removeEventListener("focus", sync);
  }, []);

  const completed = missions.filter((mission) => done.has(mission.id)).length;

  return (
    <>
      <PageHeader title={t("missionsTitle")} subtitle={t("missionsSub")} />
      <section className="glass progress-wrap" aria-label={t("progressLabel")}>
        <div className="row-between">
          <strong>{t("progressLabel")}</strong>
          <span>{completed} / {missions.length} {t("completed")}</span>
        </div>
        <ProgressBar value={completed} max={missions.length} />
      </section>
      <div className="stack">
        {missions.map((mission) => (
          <MissionCard
            key={mission.id}
            mission={mission}
            done={done.has(mission.id)}
            onToggle={() => setDone(toggleId("missions", mission.id))}
          />
        ))}
      </div>
    </>
  );
}
