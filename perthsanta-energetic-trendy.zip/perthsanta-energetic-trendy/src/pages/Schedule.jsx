import { useLang } from "../context/LanguageContext";
import PageHeader from "../components/PageHeader";
import ScheduleCard from "../components/ScheduleCard";
import { schedule } from "../data/schedule";

export default function Schedule() {
  const { t } = useLang();
  return (
    <>
      <PageHeader title={t("scheduleTitle")} subtitle={t("scheduleSub")} />
      <div className="stack">
        {schedule.map((item) => <ScheduleCard key={item.id} item={item} />)}
      </div>
    </>
  );
}
