import { Link } from "react-router-dom";
import { useLang } from "../context/LanguageContext";
import PageHeader from "../components/PageHeader";
import { todos } from "../data/todos";
import { toggleId } from "../utils/storage";

export default function Todo({ doneIds, setDoneIds }) {
  const { t } = useLang();
  return (
    <>
      <PageHeader title={t("todoTitle")} subtitle={t("todoSub")} />
      <div className="stack">
        {todos.map((item) => {
          const done = doneIds.has(item.id);
          return (
            <article key={item.id} className="glass" style={{ padding: 16 }}>
              <h2 style={{ margin: 0, fontSize: 18 }}>{t(item.titleKey)}</h2>
              <p className="muted">{t(item.descKey)}</p>
              <div className="actions">
                <Link to={item.href}>{t("open")}</Link>
                <button
                  type="button"
                  className={`btn${done ? " done" : ""}`}
                  onClick={() => setDoneIds(toggleId("todos", item.id))}
                >
                  {done ? `✓ ${t("done")}` : t("complete")}
                </button>
              </div>
            </article>
          );
        })}
      </div>
    </>
  );
}
