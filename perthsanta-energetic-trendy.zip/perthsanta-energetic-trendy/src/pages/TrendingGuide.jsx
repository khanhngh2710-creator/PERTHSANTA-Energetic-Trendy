import { useLang } from "../context/LanguageContext";
import PageHeader from "../components/PageHeader";
import GlassCard from "../components/GlassCard";

const guides = [
  {
    id: "x",
    titleKey: "xTitle",
    bodyKey: "xBody",
    links: [{ href: "https://x.com/search?q=PerthSanta&src=typed_query", labelKey: "openX" }]
  },
  {
    id: "tt",
    titleKey: "ttTitle",
    bodyKey: "ttBody",
    links: [
      { href: "https://www.tiktok.com/search?q=Perth", labelKey: "openTiktokPerth" },
      { href: "https://www.tiktok.com/search?q=Santa", labelKey: "openTiktokSanta" }
    ]
  },
  {
    id: "ig",
    titleKey: "igTitle",
    bodyKey: "igBody",
    links: [{ href: "https://www.instagram.com/explore/tags/perthsanta/", labelKey: "openIg" }]
  },
  {
    id: "fb",
    titleKey: "fbTitle",
    bodyKey: "fbBody",
    links: [{ href: "https://www.facebook.com/search/top?q=PerthSanta", labelKey: "openFb" }]
  }
];

export default function TrendingGuide() {
  const { t } = useLang();
  return (
    <>
      <PageHeader title={t("guideTitle")} subtitle={t("guideSub")} />
      <div className="stack">
        {guides.map((guide) => (
          <GlassCard key={guide.id} className="guide">
            <details>
              <summary>{t(guide.titleKey)}</summary>
              <div className="body">
                <p className="muted" style={{ margin: 0 }}>{t(guide.bodyKey)}</p>
                <div className="actions">
                  {guide.links.map((link) => (
                    <a key={link.href} href={link.href} target="_blank" rel="noreferrer">{t(link.labelKey)}</a>
                  ))}
                </div>
                <ul className="tips">
                  <li>{t("tipNew")}</li>
                  <li>{t("tipMedia")}</li>
                </ul>
              </div>
            </details>
          </GlassCard>
        ))}
      </div>
    </>
  );
}
