import { useState } from "react";
import { Link } from "react-router-dom";
import { useLang } from "../context/LanguageContext";
import PageHeader from "../components/PageHeader";
import EpisodeSelector from "../components/EpisodeSelector";
import GlassCard from "../components/GlassCard";
import ScheduleCard from "../components/ScheduleCard";
import { episodes, generators } from "../data/episodes";
import { trendEvent } from "../data/schedule";

export default function Trends() {
  const { t } = useLang();
  const [selectedId, setSelectedId] = useState(6);
  const episode = episodes.find((item) => item.id === selectedId) || episodes[0];

  return (
    <>
      <PageHeader title={t("trendsTitle")} subtitle={t("trendsSub")} />
      <p className="eyebrow">{t("trendsHeading")}</p>
      <EpisodeSelector episodes={episodes} selectedId={selectedId} onSelect={setSelectedId} />
      <GlassCard className="section-card">
        <h2 style={{ margin: "12px 0 0" }}>{t("episode")} {episode.id}</h2>
        <p className="muted">{episode.title}. {episode.note}</p>
        <h3 style={{ marginBottom: 0 }}>{t("generators")}</h3>
        <div className="gen-list">
          {generators.map((generator) => (
            <div className="gen-row" key={generator.id}>
              <span>{t(generator.nameKey)}</span>
              <span className="pill">{generator.available ? t("open") : t("comingSoon")}</span>
            </div>
          ))}
        </div>
      </GlassCard>
      <h2 style={{ marginTop: 22 }}>{t("trendXToday")}</h2>
      <p className="muted">{t("todayEvent")}</p>
      <ScheduleCard item={trendEvent} />
      <div className="actions" style={{ marginTop: 12 }}>
        <Link to="/trending-guide">{t("guideTitle")}</Link>
        <Link to="/schedule">{t("openSchedule")}</Link>
      </div>
    </>
  );
}
