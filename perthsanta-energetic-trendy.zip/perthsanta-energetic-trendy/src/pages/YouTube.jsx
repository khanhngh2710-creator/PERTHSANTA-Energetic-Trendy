import { useLang } from "../context/LanguageContext";
import PageHeader from "../components/PageHeader";
import YouTubeCard from "../components/YouTubeCard";
import { youtubeVideos } from "../data/youtube";

export default function YouTubePage() {
  const { t } = useLang();
  return (
    <>
      <PageHeader title={t("ytTitle")} subtitle={t("ytSub")} />
      <p className="eyebrow">{t("ytHeading")}</p>
      <h2>{t("trailerPilot")}</h2>
      <div className="stack">
        {youtubeVideos.map((video) => <YouTubeCard key={video.id} video={video} />)}
      </div>
      <p className="footer-note">{t("staticNote")}</p>
    </>
  );
}
