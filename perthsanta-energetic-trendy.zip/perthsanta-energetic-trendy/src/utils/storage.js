const PREFIX = "perthsanta.";

export function loadIds(key) {
  try {
    const raw = localStorage.getItem(PREFIX + key);
    const parsed = raw ? JSON.parse(raw) : [];
    return new Set(Array.isArray(parsed) ? parsed : []);
  } catch {
    return new Set();
  }
}

export function saveIds(key, ids) {
  localStorage.setItem(PREFIX + key, JSON.stringify([...ids]));
}

export function toggleId(key, id) {
  const next = loadIds(key);
  if (next.has(id)) next.delete(id);
  else next.add(id);
  saveIds(key, next);
  return next;
}
